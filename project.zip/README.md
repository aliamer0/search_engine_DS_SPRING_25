# search_engine_DS_SPRING_25
Distributed computing Project to create a distributed crawling system and indexer
