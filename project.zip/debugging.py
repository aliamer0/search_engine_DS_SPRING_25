if 1 in range(9):
    print("True")

s = {}

if s:
    print("True")

else:
    print("False")
